from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Flight, Booking
from .forms import FlightSearchForm, BookingForm

def index_view(request):
    return render(request, "index.html", {"user": request.user})

def home_view(request):
    return render(request, "index.html")

def account_view(request):
    return render(request, "Account.html")

def login_view(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("index")
        else:
            return render(request, "Account.html", {"error": "Невірний логін або пароль"})

    return render(request, "Account.html")

def register_view(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]

        if User.objects.filter(username=username).exists():
            return render(request, "Account.html", {"error": "Користувач вже існує"})

        user = User.objects.create_user(username=username, email=email, password=password)
        login(request, user)
        return redirect("index")

    return render(request, "Account.html")

@login_required
def profile_view(request):
    return render(request, "profile.html", {"user": request.user})

@login_required
def logout_view(request):
    logout(request)
    return redirect("login")

@login_required
def book_flight(request, flight_id):
    flight = get_object_or_404(Flight, id=flight_id)
    if request.method == "POST":
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.is_paid = False
            booking.is_cancelled = False
            booking.save()
            return redirect('payment', booking_id=booking.id)
    else:
        form = BookingForm(initial={'flight': flight})
    return render(request, 'booking.html', {'form': form, 'flight': flight})



