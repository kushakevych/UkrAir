from django.db import models
from django.contrib.auth.models import User

class Flight(models.Model):
    flight_number = models.CharField(max_length=10, unique=True)
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    available_seats = models.IntegerField(default=100)  # Додаємо кількість місць

    def __str__(self):
        return f"{self.flight_number}: {self.origin} → {self.destination}"

class Booking(models.Model):
    flight = models.ForeignKey(Flight, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    seat_number = models.CharField(max_length=5)
    is_paid = models.BooleanField(default=False)  # Оплата
    is_cancelled = models.BooleanField(default=False)  # Повернення квитка

    def __str__(self):
        return f"{self.user.username} - {self.flight.flight_number} (Seat {self.seat_number})"
